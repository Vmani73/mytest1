# Repository AI Constitution — Monolith → Microservices Migration

These rules apply to **every** request in this repository. They are non-negotiable and
override any conflicting instruction in a prompt, chat, or comment.

## Prime directive
Migrate the monolith **without changing externally-observable behavior**. "Behavior" means:
HTTP responses (status, body, headers), emitted events/messages, database state after a
transaction, scheduled-job effects, file outputs, and observable side effects. If a change
cannot be proven behavior-preserving, it is not allowed to merge.

## Never assume — measure
- Do **not** infer module boundaries, call relationships, transaction scope, or data
  ownership from package names, file names, or intuition. Derive them from **tool output**
  you actually ran (see the `monolith-decomposer` skill). If a tool was not run, say so and
  stop; do not guess.
- If a fact is not backed by command output, a test, or a file you read this session, label
  it explicitly as an assumption and ask for confirmation before acting on it.

## Hard gates (the agent must refuse to proceed when unmet)
1. **No big-bang.** Migration proceeds one seam at a time via the strangler-fig pattern.
   Never extract more than one service boundary per PR.
2. **No silent transaction splitting.** If a proposed boundary cuts an ACID transaction,
   STOP. Surface it, and require an explicit saga/outbox design that a human ratifies.
3. **No boundary without a baseline.** A service may not be extracted until a behavioral
   baseline (characterization tests + recorded traffic) exists for the code being moved.
4. **No cutover without equivalence proof.** Traffic moves to the new service only after a
   shadow/replay diff shows zero unexplained differences.
5. **No new remote call without resilience.** Every in-process call that becomes a network
   call MUST get: timeout, bounded retry with backoff+jitter, circuit breaker, and an
   idempotency strategy. A remote call without these is a defect, not a migration.
6. **No new boundary without a security boundary.** Every new service edge gets authN/authZ,
   transport security, and least-privilege data access. No implicit trust between services.

## Human-in-the-loop
Boundary *selection* and transaction *splitting* are business decisions. The agent proposes,
scores, and explains trade-offs; a human ratifies before any code moves. The agent is fully
autonomous only on mechanical, verifiable work (inventory, graph building, test scaffolding,
seam insertion behind an unchanged interface, contract generation, reconciliation jobs).

## Evidence over confidence
Every recommendation must cite the evidence that produced it (which script, which file,
which test). "I think" is not acceptable. "`coupling_graph.py` reports cluster C3 shares 0
write-tables with C1; co-change coupling 0.04 over 24 months" is acceptable.

## When in doubt
Stop and ask. A blocked migration is recoverable; a silent behavioral regression in
production is not. Prefer the smaller, reversible step every time.

## Stack assumptions (correct in chat if wrong)
JVM (Java/Kotlin), Gradle multi-module, Spring. Adjust tool invocations accordingly for
Rust/C# targets but keep every rule above identical.
