# Monolith → Microservices migration agent (`.github/` drop-in)

A production-grade, verification-first migration system for **GitHub Copilot Agent Mode in
VS Code**. It decomposes a large multi-module JVM/Gradle monolith into microservices **without
changing observable behavior** — safety comes from gates, deterministic analysis, and proof of
behavioral equivalence, not from the model guessing.

## Install
Copy this `.github/` folder to the **root of the monolith repo**. In VS Code:
- Custom instructions (`copilot-instructions.md`) and path instructions (`instructions/`) apply
  automatically.
- Reusable prompts (`prompts/*.prompt.md`) are invoked by typing their name in Copilot Chat.
- The skill (`skills/monolith-decomposer/`) is discovered by name/description or invoked with
  `/monolith-decomposer`.

Enable agent mode: `chat.agent.enabled: true`. For monorepos, also set
`chat.useCustomizationsInParentRepositories: true`.

## Use (the workflow is a gated state machine)
1. `/decompose` — phases 0–2: inventory → domain/flow recovery → scored boundaries. **Stops**
   for human ratification. Moves no code.
2. Ratify a boundary by adding a line to `migration/STATE.md`.
3. `/extract-service` — phases 3–5: strangler extraction → equivalence proof → harden + cut over,
   for **one** service. Repeat per service.
4. `/verify-equivalence` — run the phase-4 gate any time and get a hard PASS/FAIL.

## What makes it not a toy
- **Deterministic analysis** (`scripts/`) — the agent runs `inventory.sh`, `cochange.sh`,
  `coupling_graph.py` and reads real output instead of hallucinating structure.
- **Six gated phases** with exit criteria recorded in `migration/STATE.md` (resumable, auditable).
- **Behavioral-equivalence oracle** (record-replay-diff + characterization + contracts +
  reconciliation) — cutover is forbidden until unexplained diffs = 0.
- **Human-ratified boundaries**; **one seam per PR**; **everything reversible** behind a flag.
- **Resilience + security** mandatory on every new network edge.

## Layout
```
.github/
├── copilot-instructions.md                # always-on safety constitution
├── instructions/
│   ├── migration-safety.instructions.md    # per-edit behavior-preservation rules
│   └── gradle-multimodule.instructions.md  # multi-module/multi-gradle rules
├── prompts/
│   ├── decompose.prompt.md                 # /decompose  (analyze, propose)
│   ├── extract-service.prompt.md           # /extract-service (migrate one seam)
│   └── verify-equivalence.prompt.md        # /verify-equivalence (the gate)
└── skills/monolith-decomposer/
    ├── SKILL.md                            # orchestrator / state machine
    ├── phase-0-inventory.md … phase-5-hardening.md
    └── scripts/{inventory.sh,cochange.sh,coupling_graph.py}
```

## Scripts: prerequisites
`bash`, `git`, `python3`. Optional: `ripgrep` (faster search), `networkx` + `python-louvain`
(better community detection — falls back gracefully if absent), a running APM/OTel backend for
phase-1 runtime traces, Debezium for CDC, Pact/Spring Cloud Contract for contract tests.

Stack assumption: JVM/Gradle/Spring. For Rust/C# targets the gates are identical; adjust the
script search patterns and build commands.
