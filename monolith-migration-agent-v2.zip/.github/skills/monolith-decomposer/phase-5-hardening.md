# Phase 5 — Hardening, Security & Cutover

**Goal:** make the new edge production-safe, then cut traffic over and remove the old path.
**Exit gate:** constitution gates 5 (resilience) & 6 (security) satisfied; traffic cut over
behind a flag with monitoring; old in-monolith path deleted; `STATE.md` updated.

## Resilience on every new remote call (constitution gate 5)
An in-process method call that became a network call can now time out, fail partially, retry-
storm, or reorder. Each cut edge from phase 2 MUST have:
- **Timeout** (connect + read), tuned to the latency budget — never unbounded.
- **Retry** with exponential backoff + jitter, bounded attempts, only on idempotent ops.
- **Circuit breaker** (Resilience4j) with a defined fallback/degradation behavior.
- **Bulkhead / concurrency limit** so one slow dependency can't exhaust threads.
- **Idempotency** keys for any state-changing call so a retry can't double-apply.
- **Backpressure / dead-letter** handling for async edges.
A remote call missing any of these is a defect, not a finished migration.

## Security boundary (constitution gate 6)
Every new service edge is a new attack surface. Add:
- **AuthN/AuthZ** between services (mTLS + service identity, or signed tokens/OAuth2 client
  credentials). No implicit trust because "it's internal."
- **Transport security** (TLS everywhere) and **least-privilege data access** — the new
  service's DB credentials grant only the tables it owns.
- **Secrets** via the platform secret store (no secrets in config or images).
- **Input validation at the boundary** — the monolith may have trusted in-process callers;
  the service must not.
- Re-run the org security scan against the new service before cutover (ties into existing
  remediation/CI gates).

## Observability before cutover (not after)
- Distributed tracing spans the new edge; logs are correlated by trace ID; metrics (RED:
  rate/errors/duration) and dashboards exist; alerts on error rate and latency budget breach.
- You cannot operate or roll back safely what you cannot see.

## Progressive cutover
1. **Shadow** (already running from phase 4): new path called, result discarded.
2. **Canary**: flip the flag for a small traffic % ; watch RED metrics + diff alarms.
3. **Ramp**: increase % in stages, each stage gated on clean metrics.
4. **100%**: new path is default; old path still wired (instant rollback = flip flag).
5. **Decommission**: after a soak period with clean metrics, delete the old in-monolith path,
   its dead code, and (after the dual-write window + clean reconciliation) the old data path.

## Rollback
At every stage above, rollback is: flip the feature flag back to the old path, redeploy if
needed. Document it in the PR and verify it works in staging before canary.

## Exit checklist (record in STATE.md, then loop to phase 3 for next service)
- [ ] Every cut edge has timeout + retry + breaker + bulkhead + idempotency
- [ ] AuthN/AuthZ, TLS, least-privilege data access, secrets in vault, boundary validation
- [ ] Tracing/metrics/logs/alerts live for the new edge
- [ ] Canary → ramp → 100% completed with clean metrics at each gate
- [ ] Old path + dead code removed; data path retired after clean reconciliation
- [ ] STATE.md updated; monolith is one service smaller
