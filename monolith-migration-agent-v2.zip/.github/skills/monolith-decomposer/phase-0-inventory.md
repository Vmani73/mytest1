# Phase 0 — Discovery & Inventory (zero assumptions)

**Goal:** a complete, machine-readable map of what exists, before anyone proposes a boundary.
**Exit gate:** `migration/inventory.json` exists and accounts for *every* Gradle module. Any
module not covered = phase not complete.

## Run this first
```
bash .github/skills/monolith-decomposer/scripts/inventory.sh > migration/inventory.json
```
Read the JSON. Do not summarize the codebase from memory — summarize from this file.

## What must be captured (the script collects these; verify nothing is missing)
1. **Build topology** — every Gradle module, its path, and its declared dependencies
   (inter-module *and* external). Cross-check with `./gradlew :projects` and
   `./gradlew :<m>:dependencies` for modules with dynamic/conditional deps.
2. **Entry points** — every way the outside world triggers code:
   - HTTP: `@RestController`, `@Controller`, `@RequestMapping`, JAX-RS, GraphQL resolvers.
   - Async in: `@KafkaListener`, `@JmsListener`, `@RabbitListener`, `@SqsListener`, `@StreamListener`.
   - Scheduled/batch: `@Scheduled`, Quartz jobs, Spring Batch `Job`/`Step`, `main()` entry classes.
   - CLI / `CommandLineRunner` / `ApplicationRunner`.
3. **Persistence & data ownership** — `@Entity`, `@Table`, `@Repository`, JPA/MyBatis mappers,
   `@Query` (JPQL + native), `*.sql`, Flyway/Liquibase migrations, stored procedures, the set
   of tables each module reads vs writes. **Write-sets are the real ownership signal.**
4. **Integration egress** — `RestTemplate`, `WebClient`, `FeignClient`, `@HttpExchange`,
   gRPC stubs, `JmsTemplate`, `KafkaTemplate`, SOAP clients, file/FTP/S3 I/O, cache clients.
5. **Cross-cutting config** — `application*.yml/properties`, profiles, feature flags,
   `@ConfigurationProperties`, externalized secrets, scheduler cron expressions.
6. **Existing guarantees to preserve** — current ArchUnit rules, existing tests (and their
   coverage of entry points), transaction annotations (`@Transactional` scope is gold).

## Capture transaction scope explicitly
List every `@Transactional` boundary and what tables/aggregates it touches. This is the
single most important artifact for phase 2 — a service boundary that splits one of these
transactions is a distributed-transaction problem and must be flagged, never assumed safe.

## Coverage gaps = risk register
Any entry point with **no test** and **no observability** is a blind spot. Record these in
`migration/RISK.md`. You cannot prove you didn't break what you cannot observe; these get a
characterization test in phase 4 before their owning code is touched.

## Exit checklist (write results to STATE.md)
- [ ] `inventory.json` covers all modules (count matches `./gradlew :projects`)
- [ ] Every entry point classified
- [ ] Per-module read-set and write-set of tables recorded
- [ ] All `@Transactional` scopes listed with their table/aggregate footprint
- [ ] Untested/unobserved entry points logged in `RISK.md`
