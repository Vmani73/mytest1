# Phase 2 — Boundary Selection (graph partitioning, human-ratified)

**Goal:** turn the domain map into *scored* candidate service boundaries. The agent proposes
and explains; a **human ratifies**. Boundary choice is a business decision, not a graph output.
**Exit gate:** a ratified boundary set recorded in `migration/STATE.md` with a human sign-off line.

## Treat it as constrained graph partitioning
```
python3 .github/skills/monolith-decomposer/scripts/coupling_graph.py \
  --inventory migration/inventory.json \
  --cochange migration/cochange.json \
  --out migration/boundaries.json
```
- **Nodes:** classes and tables.
- **Edge weight:** weighted blend of (a) static calls/imports, (b) runtime co-invocation from
  traces, (c) git co-change, (d) shared data access. Tune the blend; record the weights used.
- **Algorithm:** community detection (Louvain/Leiden) **seeded** by the phase-1 bounded
  contexts and **hard-constrained** so no cluster splits a single-aggregate transaction.

## Score every candidate boundary
For each proposed service, report:
- **Cohesion** (intra-cluster edge weight) and **coupling** (cut-edge weight). High cohesion,
  low coupling = good seam.
- **Cut edges** = every in-process call that becomes a network call. This is the *risk surface*.
  List them explicitly; each one needs resilience + security later.
- **Data verdict:** does the boundary own its tables cleanly, or does it share a write-table
  with another service? Shared write-tables ⇒ data split required (phase 3) or boundary rejected.
- **Transaction verdict:** does it split any `@Transactional` from the domain map? If yes,
  flag as **SAGA-REQUIRED** — do not present it as a clean extraction.
- **Blast radius:** how many entry points and downstream consumers are affected.
- **Migration cost vs business value:** rough order-of-effort and why this service matters.

## Recommend an extraction order (decisive — no "it depends")
Order by: lowest coupling first (leaf services), then highest business value, then lowest data
entanglement. State the recommended first service and the one-line reason. Leaf services with
clean data ownership and no cut transactions go first — they build the muscle and the harness
with the least risk.

## Hand to human for ratification
Present the scored set + recommended order. Do **not** proceed to phase 3 until a human writes
a ratification line in `STATE.md` (e.g. `RATIFIED 2026-06-07 by <name>: extract "Notification"
first`). If the human changes a boundary, re-score; never quietly accept an unscored boundary.

## Exit checklist
- [ ] boundaries.json with cohesion/coupling/cut-edges per candidate
- [ ] Every SAGA-REQUIRED and shared-write-table boundary flagged
- [ ] Recommended extraction order with rationale
- [ ] Human ratification line in STATE.md
