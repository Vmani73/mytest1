#!/usr/bin/env bash
# cochange.sh — logical coupling from git history: which files change together.
# Files that co-change belong to the same business capability more reliably than
# files that merely call each other. Output: JSON {pairs:[{a,b,count,score}]} to stdout.
#
# Usage: bash cochange.sh [MONTHS]   (default 24). Run from repo root.
set -uo pipefail
MONTHS="${1:-24}"
SINCE="$(date -d "-${MONTHS} months" +%Y-%m-%d 2>/dev/null || date -v-"${MONTHS}"m +%Y-%m-%d)"

if ! command -v git >/dev/null 2>&1 || ! git rev-parse --git-dir >/dev/null 2>&1; then
  echo '{"error":"not a git repository or git unavailable"}'; exit 0
fi

LOG="$(mktemp)"; trap 'rm -f "$LOG"' EXIT
git log --since="$SINCE" --pretty=format:'@@COMMIT@@' --name-only > "$LOG" 2>/dev/null

# Pass the log path as an arg; read it inside python (heredoc must own stdin).
python3 - "$MONTHS" "$LOG" <<'PY'
import sys, json
from collections import Counter
from itertools import combinations
months, logpath = sys.argv[1], sys.argv[2]
EXT = ('.java', '.kt')
commits, cur = [], []
with open(logpath, encoding='utf-8', errors='ignore') as fh:
    for line in fh:
        line = line.rstrip("\n")
        if line == "@@COMMIT@@":
            if cur: commits.append(cur); cur=[]
        elif line.strip() and line.strip().endswith(EXT):
            cur.append(line.strip())
if cur: commits.append(cur)
commits = [c for c in commits if c]

file_freq = Counter(); pair = Counter()
for files in commits:
    files = sorted(set(files))
    if len(files) > 50:        # skip mega-commits (reformat/dependency bumps) — noise
        continue
    for f in files: file_freq[f]+=1
    for a,b in combinations(files,2): pair[(a,b)] += 1

out=[]
for (a,b),c in pair.items():
    if c < 2: continue
    denom = min(file_freq[a], file_freq[b]) or 1     # normalized logical coupling
    out.append({"a":a,"b":b,"count":c,"score":round(c/denom,3)})
out.sort(key=lambda x:(-x["score"], -x["count"]))
print(json.dumps({"window_months":int(months),"commits_analyzed":len(commits),"pairs":out[:2000]}, indent=2))
PY
