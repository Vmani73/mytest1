#!/usr/bin/env bash
# inventory.sh — deterministic inventory of a JVM/Gradle monolith.
# Output: JSON to stdout. Run from repo root. The agent reads this output;
# it must NOT describe the codebase structure without it.
#
# Usage: bash inventory.sh > migration/inventory.json
set -uo pipefail

# Prefer ripgrep; fall back to grep -r.
if command -v rg >/dev/null 2>&1; then SEARCH() { rg -l --no-messages "$1" -g '*.java' -g '*.kt' . ; }
else SEARCH() { grep -rlE "$1" --include='*.java' --include='*.kt' . 2>/dev/null ; }
fi

json_array() { # turn newline list on stdin into a JSON string array
  local first=1; printf '['
  while IFS= read -r line; do [ -z "$line" ] && continue
    [ $first -eq 0 ] && printf ','; first=0
    printf '%s' "\"$(printf '%s' "$line" | sed 's/\\/\\\\/g; s/"/\\"/g')\""
  done; printf ']'
}

echo "{"

# --- Gradle modules -------------------------------------------------------
echo '  "gradle_modules":'
{ find . -name 'build.gradle' -o -name 'build.gradle.kts' 2>/dev/null | sed 's|/build.gradle.*||'; } | sort -u | json_array
echo ','

# --- Entry points ---------------------------------------------------------
echo '  "entry_points": {'
echo -n '    "http": ';        SEARCH '@([A-Za-z0-9_]+\.)*(RestController|Controller|RequestMapping|GetMapping|PostMapping)\b' | json_array; echo ','
echo -n '    "messaging_in": '; SEARCH '@([A-Za-z0-9_]+\.)*(KafkaListener|JmsListener|RabbitListener|SqsListener|StreamListener)\b' | json_array; echo ','
echo -n '    "scheduled": ';   SEARCH '@([A-Za-z0-9_]+\.)*(Scheduled)\b|implements\s+Job\b|extends\s+QuartzJobBean' | json_array; echo ','
echo -n '    "batch": ';       SEARCH 'JobBuilder|StepBuilder|@EnableBatchProcessing' | json_array; echo ','
echo -n '    "runners": ';     SEARCH 'implements\s+(CommandLineRunner|ApplicationRunner)|public\s+static\s+void\s+main' | json_array
echo '  },'

# --- Persistence & data ownership ----------------------------------------
echo '  "persistence": {'
echo -n '    "entities": ';    SEARCH '@([A-Za-z0-9_]+\.)*(Entity|Table)\b' | json_array; echo ','
echo -n '    "repositories": ';SEARCH '@([A-Za-z0-9_]+\.)*(Repository)\b|extends\s+(JpaRepository|CrudRepository|MongoRepository)' | json_array; echo ','
echo -n '    "native_queries": '; SEARCH '@Query\(.*nativeQuery\s*=\s*true' | json_array; echo ','
echo -n '    "sql_files": ';   { find . -name '*.sql' 2>/dev/null; } | json_array; echo ','
echo -n '    "migrations": ';  { find . -path '*db/migration*' -o -name 'changelog*.xml' -o -name 'changelog*.yaml' 2>/dev/null; } | json_array
echo '  },'

# --- Integration egress ---------------------------------------------------
echo '  "integration_egress": {'
echo -n '    "http_clients": '; SEARCH 'RestTemplate|WebClient|@FeignClient|@HttpExchange' | json_array; echo ','
echo -n '    "messaging_out": '; SEARCH 'KafkaTemplate|JmsTemplate|RabbitTemplate|StreamBridge' | json_array; echo ','
echo -n '    "grpc": ';        SEARCH 'GrpcService|ManagedChannel|BlockingStub' | json_array; echo ','
echo -n '    "soap_file_io": ';SEARCH 'WebServiceTemplate|@WebServiceClient|FTPClient|AmazonS3|S3Client' | json_array
echo '  },'

# --- Transaction boundaries (the most important signal for phase 2) ------
echo -n '  "transactional_sites": '; SEARCH '@([A-Za-z0-9_]+\.)*Transactional\b' | json_array; echo ','

# --- Config & flags -------------------------------------------------------
echo '  "config": {'
echo -n '    "files": '; { find . \( -name 'application*.yml' -o -name 'application*.yaml' -o -name 'application*.properties' -o -name 'bootstrap*.yml' \) 2>/dev/null; } | json_array; echo ','
echo -n '    "config_properties": '; SEARCH '@ConfigurationProperties\b' | json_array
echo '  },'

# --- Existing guarantees --------------------------------------------------
echo '  "existing_guarantees": {'
echo -n '    "archunit_rules": '; SEARCH 'ArchRule|ArchRuleDefinition|@AnalyzeClasses' | json_array; echo ','
echo -n '    "test_files": ';     { find . -path '*/test/*' \( -name '*.java' -o -name '*.kt' \) 2>/dev/null; } | json_array
echo '  }'

echo "}"
