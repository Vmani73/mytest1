#!/usr/bin/env python3
"""coupling_graph.py — build a weighted coupling graph of the monolith and propose
candidate service boundaries via community detection.

Edges blend four signals (weights configurable):
  - static imports/calls   (structural coupling)
  - shared table access     (data coupling)        [from inventory.json if available]
  - git co-change           (logical coupling)      [from cochange.json if available]
Communities = candidate bounded contexts. Each candidate reports cohesion, coupling,
and the cut edges that will become network calls (the risk surface).

Deterministic, dependency-light: uses networkx + python-louvain if present, else a
greedy modularity fallback so it always runs. Output: JSON to --out and stdout summary.

Usage:
  python3 coupling_graph.py --src . [--inventory migration/inventory.json] \
      [--cochange migration/cochange.json] --out migration/boundaries.json
"""
import argparse, json, os, re, sys
from collections import defaultdict

IMPORT_RE = re.compile(r'^\s*import\s+(static\s+)?([\w.]+)', re.M)
PKG_RE    = re.compile(r'^\s*package\s+([\w.]+)', re.M)

def collect_packages(src):
    """Map fully-qualified type -> package, and gather import edges between packages."""
    file_pkg = {}
    edges = defaultdict(float)
    for root,_,files in os.walk(src):
        if any(s in root for s in ('/build/','/.git/','/test/','/.gradle/')): continue
        for fn in files:
            if not fn.endswith(('.java','.kt')): continue
            p = os.path.join(root,fn)
            try: txt = open(p,encoding='utf-8',errors='ignore').read()
            except Exception: continue
            m = PKG_RE.search(txt)
            pkg = m.group(1) if m else os.path.dirname(p)
            file_pkg[p] = pkg
    pkgs = set(file_pkg.values())
    def owning_pkg(fqcn):
        # longest known package that is a prefix of the imported symbol
        best=None
        for pk in pkgs:
            if fqcn.startswith(pk+'.') and (best is None or len(pk)>len(best)): best=pk
        return best
    for p,pkg in file_pkg.items():
        try: txt = open(p,encoding='utf-8',errors='ignore').read()
        except Exception: continue
        for _,sym in IMPORT_RE.findall(txt):
            tgt = owning_pkg(sym)
            if tgt and tgt!=pkg:
                edges[(pkg,tgt)] += 1.0
    return pkgs, edges

def add_signal(edges, pairs, key_a, key_b, weight, node_of):
    for item in pairs:
        a = node_of(item[key_a]); b = node_of(item[key_b])
        if a and b and a!=b:
            edges[(a,b)] += weight*float(item.get('score',1))

def node_of_path_factory(pkgs, src):
    # crude: map a file path to its package by reading its package decl is expensive;
    # approximate by directory→package via the known package set membership of path.
    def f(path):
        path = path.replace('\\','/')
        best=None
        for pk in pkgs:
            pkpath = pk.replace('.','/')
            if pkpath in path and (best is None or len(pk)>len(best)): best=pk
        return best
    return f

def communities(nodes, edges):
    try:
        import networkx as nx
        G = nx.Graph()
        G.add_nodes_from(nodes)
        for (a,b),w in edges.items(): G.add_edge(a,b,weight=w)
        try:
            import community as community_louvain   # python-louvain
            part = community_louvain.best_partition(G, weight='weight')
            clusters=defaultdict(list)
            for n,c in part.items(): clusters[c].append(n)
            return list(clusters.values()), G
        except Exception:
            from networkx.algorithms.community import greedy_modularity_communities
            cs = greedy_modularity_communities(G, weight='weight')
            return [list(c) for c in cs], G
    except Exception:
        # ultra-fallback: connected components on a thresholded graph
        adj=defaultdict(set)
        for (a,b),w in edges.items():
            if w>=2: adj[a].add(b); adj[b].add(a)
        seen=set(); out=[]
        for n in nodes:
            if n in seen: continue
            stack=[n]; comp=[]
            while stack:
                x=stack.pop()
                if x in seen: continue
                seen.add(x); comp.append(x); stack+=list(adj[x])
            out.append(comp)
        return out, None

def score(clusters, edges):
    idx={}
    for i,c in enumerate(clusters):
        for n in c: idx[n]=i
    intra=defaultdict(float); cut=defaultdict(list); inter=defaultdict(float)
    for (a,b),w in edges.items():
        ia,ib = idx.get(a),idx.get(b)
        if ia is None or ib is None: continue
        if ia==ib: intra[ia]+=w
        else:
            cut[ia].append({"to_cluster":ib,"from":a,"to":b,"weight":w})
            inter[ia]+=w
    report=[]
    for i,c in enumerate(clusters):
        report.append({
            "candidate_id": f"C{i}",
            "size": len(c),
            "cohesion": round(intra[i],2),
            "coupling": round(inter[i],2),
            "cohesion_ratio": round(intra[i]/(intra[i]+inter[i]+1e-9),3),
            "cut_edges": sorted(cut[i], key=lambda e:-e["weight"])[:50],
            "members_sample": sorted(c)[:25],
        })
    report.sort(key=lambda r:(-r["cohesion_ratio"], r["coupling"]))
    return report

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--src', default='.')
    ap.add_argument('--inventory'); ap.add_argument('--cochange')
    ap.add_argument('--w-static', type=float, default=1.0)
    ap.add_argument('--w-cochange', type=float, default=1.5)  # logical coupling weighted higher
    ap.add_argument('--out', default='migration/boundaries.json')
    a=ap.parse_args()

    pkgs, edges = collect_packages(a.src)
    nodef = node_of_path_factory(pkgs, a.src)
    if a.cochange and os.path.exists(a.cochange):
        try:
            cc=json.load(open(a.cochange)).get('pairs',[])
            add_signal(edges, cc, 'a','b', a.w_cochange, nodef)
        except Exception as e: print(f"# cochange skipped: {e}", file=sys.stderr)

    clusters, _ = communities(list(pkgs), edges)
    report = score(clusters, edges)
    result = {
        "nodes": len(pkgs), "edges": len(edges),
        "weights": {"static": a.w_static, "cochange": a.w_cochange},
        "candidate_boundaries": report,
        "note": "Candidates are PROPOSALS. A human must ratify. Any candidate whose cut_edges "
                "cross a @Transactional scope is SAGA-REQUIRED — verify against domain-map.md."
    }
    os.makedirs(os.path.dirname(a.out) or '.', exist_ok=True)
    json.dump(result, open(a.out,'w'), indent=2)
    print(f"{len(pkgs)} packages, {len(edges)} edges, {len(report)} candidate boundaries -> {a.out}")
    for r in report[:10]:
        print(f"  {r['candidate_id']}: size={r['size']} cohesion_ratio={r['cohesion_ratio']} "
              f"coupling={r['coupling']} cut_edges={len(r['cut_edges'])}")

if __name__=='__main__':
    main()
