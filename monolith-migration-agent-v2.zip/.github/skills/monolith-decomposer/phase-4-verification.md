# Phase 4 — Behavioral Equivalence (the proof that nothing broke)

**Goal:** *prove*, not assert, that the extracted service behaves identically to the old path.
This phase is why the migration is safe. **Exit gate:** shadow/replay diff shows **zero
unexplained differences** across the agreed traffic sample; contract tests green.

## Layer the verification (each layer catches what the others miss)

### 1. Characterization baseline (capture BEFORE any cutover)
- Generate golden-master / characterization tests around the moved capability's entry points,
  pinning current outputs (status, body, headers, emitted events, resulting DB state). For
  entry points logged as untested in phase 0's `RISK.md`, this is mandatory before cutover.
- These tests assert *what the code does today*, not what it "should" do. Behavior preservation,
  not correctness improvement.

### 2. Record–replay–diff (shadow / parallel run) — the centerpiece
- **Record** real production (or staging) traffic at the seam: request, full response, and
  side effects (DB writes, emitted messages).
- **Replay** the same inputs against the new service in shadow mode (result discarded, old
  path still serves users).
- **Diff** new vs recorded: response equality, event equality, and DB-state equality.
- Classify every diff: *true regression* (block), *known intentional* (whitelist with reason),
  or *nondeterminism* (timestamps, UUIDs, ordering — normalize, then re-diff). Cutover is
  forbidden while any unexplained diff remains.
- This is a behavioral-equivalence oracle: the new service must be observationally
  indistinguishable from the old under the recorded inputs.

### 3. Contract tests between services
- Consumer-driven contracts (Pact or Spring Cloud Contract) for every cut edge from phase 2.
- Provider verification runs in the new service's CI; consumer verification in the caller's.
  A contract change that breaks a consumer fails the build.

### 4. Data reconciliation
- For any data that was split/duplicated, run a reconciliation job: old store vs new store must
  agree (row counts, checksums, key business invariants). Schedule it to run during the
  dual-write window and gate cutover on a clean reconciliation.

### 5. Performance regression gate
- A previously in-process call is now a network hop. Set an explicit latency budget for the new
  edge and fail the gate if p95/p99 exceeds it. Surface added latency before users feel it.

## CI gates (wire these into the PR)
- Existing suite green + new characterization tests green.
- Replay diff job: 0 unexplained diffs over the agreed sample window.
- Contract verification green on both sides.
- Reconciliation clean.
- Latency within budget.
Only when ALL pass may phase 5 begin cutover. The agent must refuse to mark the step done
otherwise (constitution gate 4).

## Exit checklist
- [ ] Characterization baseline committed and green
- [ ] Replay-diff harness running; unexplained diffs = 0 (diffs classified + recorded)
- [ ] Contract tests green both sides
- [ ] Data reconciliation clean
- [ ] Latency within declared budget
