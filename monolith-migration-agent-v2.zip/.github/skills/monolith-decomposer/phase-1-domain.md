# Phase 1 — Business Knowledge & Flow Recovery

**Goal:** recover the *business* structure — bounded contexts, aggregates, domain events, and
the real flows — fusing three independent signals. Static analysis alone lies about coupling.
**Exit gate:** a domain map committed to `migration/domain-map.md` with transaction boundaries
marked, derived from all three signals below.

## Fuse three signals (any one alone is misleading)

### 1. Static structure
- Build the class/module call graph and import graph (from `coupling_graph.py`).
- Cohesion per package/module; shared data access; inheritance and DI wiring.
- Output: structural coupling weights between candidate units.

### 2. Runtime / dynamic truth (do not skip — this is what separates real work from a toy)
- Pull distributed traces (APM: OpenTelemetry/Zipkin/Jaeger/Dynatrace) for representative
  production windows. These reveal *actual* call paths and hot transactions that static
  analysis cannot see (reflection, AOP, dynamic dispatch, framework magic).
- Pull DB query logs / slow-query logs to see which tables are *actually* co-accessed under
  load, and the true read/write ratios.
- If no tracing exists, that is itself a finding: **observability must be installed before
  migration** (phase 5 depends on it). Record it as a blocker in `RISK.md`.

### 3. Git logical coupling (cheap, powerful, usually ignored)
```
bash .github/skills/monolith-decomposer/scripts/cochange.sh 24   # months of history
```
Files/classes that change together belong together. Logical coupling from history often beats
structural coupling for drawing boundaries — it captures the *reasons* code changes, i.e. the
business capabilities.

## Build the domain map
For each candidate bounded context, record:
- **Capability** it owns (in business language, e.g. "Loan Origination", "Payment Capture").
- **Aggregates** (the consistency units) and the **tables** they own (write-set).
- **Domain events** it publishes/consumes.
- **Entry points** that belong to it (from phase 0).
- **Transaction boundaries** it participates in — and crucially, which transactions span
  *more than one* candidate context. Mark every cross-context transaction in **bold red**;
  these are the migration's hardest risks.

## Output: `migration/domain-map.md`
A table of contexts × (capability, aggregates, owned tables, events, entry points), plus an
explicit list of cross-context transactions and shared mutable tables. This is the input to
phase 2's boundary scoring and the contract for what each future service must preserve.

## Exit checklist
- [ ] All three signals collected (static, runtime, co-change) — or runtime gap logged as blocker
- [ ] Candidate bounded contexts named in business terms
- [ ] Owned tables (write-sets) assigned per context; shared-write tables flagged
- [ ] Cross-context transactions enumerated (these drive saga decisions later)
- [ ] domain-map.md committed
