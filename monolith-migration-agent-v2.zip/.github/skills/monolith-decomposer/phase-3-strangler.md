# Phase 3 — Strangler-Fig Extraction (one seam, reversible)

**Goal:** extract exactly ONE ratified service without changing behavior, with the old path
still the default. **Exit gate:** new service runs behind a seam; old in-monolith path remains
the live default; nothing cut over yet.

## Never big-bang. The sequence is always:
1. **Introduce the seam** (branch by abstraction). Put the target capability behind an
   interface inside the monolith *without changing callers' behavior*. Commit. This is a pure
   refactor and must pass the existing test suite unchanged.
2. **Anti-corruption layer (ACL).** Define the service's contract in its own terms; translate
   to/from the monolith's model at the boundary so the monolith's leaks don't bleed into the
   new service.
3. **Stand up the new service** implementing the same interface. Same logic, relocated. No
   behavior changes, no "improvements" smuggled in — relocation only. Improvements are a
   separate PR after equivalence is proven.
4. **Route through a facade + feature flag**, defaulting to the **old** path. The new path is
   dark-launched (called in shadow, result discarded) — see phase 4.

## Data: the hardest part — handle explicitly
- **Owns its tables cleanly?** Move them to a service-owned schema/DB. Use expand-contract
  migrations (add new, dual-write, backfill, verify, cut reads, drop old) — never a destructive
  single-step migration.
- **Shares a write-table?** Choose deliberately and record the choice:
  - *Transitional shared DB* (documented, time-boxed, with a deadline to split), or
  - *Database-per-service via CDC* (Debezium) + **outbox pattern** for reliable event emission, or
  - *Data duplication* with a clear owner and eventual-consistency contract.
- **Foreign keys crossing the boundary** become either a synchronous API call or duplicated
  read-model data. State which, and why. A silent cross-service FK is a defect.

## Cross-service transactions (only if phase 2 flagged SAGA-REQUIRED)
Design an explicit **saga** with compensating actions for every step, plus the **outbox
pattern** for atomic state-change + event-emit. Document the failure/compensation matrix. A
human ratifies the saga design before code. Do not approximate a distributed transaction with
hopeful ordering.

## Keep it reversible
- Feature flag at the facade. Old path stays wired and default.
- The new service is deployable and removable without touching the monolith's behavior.
- Document the exact rollback (flip flag, redeploy) in the PR.

## Exit checklist
- [ ] Seam interface introduced; existing suite still green (pure refactor commit)
- [ ] ACL defined; new service implements the interface (relocation only, no behavior change)
- [ ] Data ownership decision recorded (owned move / CDC+outbox / duplication)
- [ ] Saga + outbox designed and ratified IF transaction was split
- [ ] Facade + feature flag in place, defaulting to old path
- [ ] Rollback documented in PR
