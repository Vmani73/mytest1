---
name: 'Migration safety invariants'
description: 'Behavior-preservation rules applied to every code edit during migration'
applyTo: '**/*.{java,kt}'
---
# Migration safety invariants (every edit)

When editing any Java/Kotlin file during the migration, enforce these without exception:

- **Relocation ≠ improvement.** When moving logic into a new service, move it *as-is*. Do not
  refactor, rename, "clean up", or fix bugs in the same change. Behavior-changing improvements
  are a separate PR made only *after* equivalence is proven. Mixing them destroys the diff proof.
- **Preserve the public contract.** Method signatures, response shapes, status codes, emitted
  events, and error semantics at any seam must stay identical unless a ratified contract change
  says otherwise.
- **Every new remote call is guarded.** If an edit turns an in-process call into a network call,
  it must include timeout + bounded retry(backoff+jitter) + circuit breaker + idempotency, or it
  is incomplete. Reference resilience helpers; do not hand-roll naked HTTP calls.
- **No new cross-boundary database access.** A service reads/writes only the tables it owns.
  Cross-boundary data needs an API call or a replicated read model — never a direct foreign-table
  query smuggled in.
- **No secret or endpoint hardcoding.** Externalize via config/secret store. Flag any literal
  URL, credential, or token.
- **Keep the old path until proven.** Do not delete the in-monolith implementation in the same
  PR that adds the new service. Removal happens only after cutover + soak (phase 5).
- **Touch tests when you touch behavior-adjacent code.** If an edit could affect an entry point
  with no test, add a characterization test first.

If a requested edit violates any of the above, refuse and explain which invariant blocks it.
