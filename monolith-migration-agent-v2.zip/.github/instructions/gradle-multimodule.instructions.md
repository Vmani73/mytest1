---
name: 'Gradle multi-module migration rules'
description: 'Rules for editing Gradle build files during decomposition'
applyTo: '**/{build.gradle,build.gradle.kts,settings.gradle,settings.gradle.kts,gradle.properties,*.gradle}'
---
# Gradle multi-module migration rules

This is a large multi-module / multi-Gradle build. When editing build files during migration:

- **Map before you cut.** Before changing any dependency, confirm the real dependency graph
  from `./gradlew :projects` and `./gradlew :<module>:dependencies` — not from reading
  `build.gradle` alone (version catalogs, conventions plugins, and `subprojects {}` blocks hide
  edges).
- **Extract a module, don't fork the build.** A new service starts as a new Gradle module (or
  an included build) that depends on the monolith's shared contracts module — never by copying
  source between modules.
- **Pull shared contracts into an API module.** Interfaces/DTOs that both the monolith and the
  new service need go into a dedicated `*-api`/`*-contract` module both depend on, so the
  contract has one source of truth.
- **Watch version drift.** When a service moves out, pin its dependency versions via the shared
  version catalog (`gradle/libs.versions.toml`) — do not introduce inline/hardcoded version
  strings that diverge from the platform. Flag any hardcoded version literal in a `build.gradle`.
- **Preserve build reproducibility.** Keep the Gradle wrapper version aligned across modules;
  do not introduce a second wrapper version. Run `./gradlew build` on affected modules before
  and after the change and confirm both pass.
- **No transitive surprises.** Use `api` vs `implementation` deliberately; prefer
  `implementation` to avoid leaking the monolith's transitive deps into the new service.

If a build edit would split a module in a way that breaks compilation or hides a runtime
dependency, stop and surface the dependency that blocks a clean cut.
